import React, { useState } from 'react';

const New = () => {
  const initialArr = ["cfrefrf", "ascasdwe", "asasasa"];
  const [arr, setArr] = useState(initialArr);

  const deleteItem = (index) => {  
const detel = arr.filter((item,i)=> { return i !== index})
    setArr(detel);
  };

  return (
    <div>
      {arr.map((item, index) => (
        <div key={index}>
          {item}
          <button onClick={() => deleteItem(index)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default New;
