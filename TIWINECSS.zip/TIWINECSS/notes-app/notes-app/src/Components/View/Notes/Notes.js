import React, { useEffect, useState } from 'react'
import { fetchNotes, updateData } from '../../Config/Config'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import axios from 'axios';

const Notes = () => {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [notes, setNotes] = useState()
  const [editNote, setEditNote] = useState()

  const fetchData = async () => {
    const response = await fetchNotes()
    if (response?.isFetch) {
      setNotes(response?.data)
    } else {
      console.log("Error Found");
    }
  }

  const handleEditOpen = (id) => {
    const findNote = notes?.find((element) => element?.id === id)
    setEditNote(findNote)
    console.log(findNote);
    handleShow()
  }

  const handleChange = (e) =>{
    setEditNote({...editNote, [e.target.name] : e.target.value})
  }

  const handleEdit =async () => {
    await updateData(editNote)
    fetchData()
    handleClose()
  }

  const handleDelete = async (id) => {
    await axios.delete(`https://notes-app-exam-default-rtdb.europe-west1.firebasedatabase.app/notes/${id}.json`)
    fetchData()
  }


  useEffect(() => {
    fetchData()
  }, [])


  return (
    <div className='container'>
      <div className="row py-5">
        {
          notes?.map((note, index) => {
            return (
              <div className='col-3' key={index}>
                <div className="card">
                  <div className="card-header">
                    Featured
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">{note?.title}</h5>
                    <p className="card-text">{note?.description}</p>
                  </div>
                  <div className="card-footer">
                    <button className='btn btn-primary px-4 py-2 me-2' onClick={() => handleEditOpen(note?.id)}>Edit</button>
                    <button className='btn btn-danger px-4 py-2' onClick={() => handleDelete(note?.id)}>Delete</button>
                  </div>
                </div>
              </div>
            )
          })
        }
      </div>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add New Note</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form action="#" >
            <div className="form-floating mb-3">
              <input type="text" className="form-control" id="floatingInput" placeholder="Enter Your Title" name='title' value={editNote?.title} onChange={handleChange} />
              <label htmlFor="floatingInput">Username</label>
            </div>
            <div className="form-floating mb-3">
              <input type="text" className="form-control" id="floatingPassword" placeholder="Description" name='description' value={editNote?.description} onChange={handleChange} />
              <label htmlFor="floatingPassword">Password</label>
            </div>
            <div className="form-Button text-center">
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleEdit}>
            Edit Note
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}

export default Notes
